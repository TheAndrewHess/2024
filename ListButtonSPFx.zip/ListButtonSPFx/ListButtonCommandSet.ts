import { Log } from '@microsoft/sp-core-library';
import {
  BaseListViewCommandSet,
  type Command,
  type IListViewCommandSetExecuteEventParameters
} from '@microsoft/sp-listview-extensibility';
import { Dialog } from '@microsoft/sp-dialog';

export interface IListButtonCommandSetProperties {
  sampleTextOne: string;
}

const LOG_SOURCE: string = 'ListButtonCommandSet';

export default class ListButtonCommandSet extends BaseListViewCommandSet<IListButtonCommandSetProperties> {

  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized ListButtonCommandSet');

    const compareOneCommand: Command = this.tryGetCommand('COMMAND_1');
    compareOneCommand.visible = true;


    return Promise.resolve();
  }

  public async onExecute(event: IListViewCommandSetExecuteEventParameters): Promise<void> {
    switch (event.itemId) {
      case 'COMMAND_1':
        await this.startFlow();
        break;
      default:
        throw new Error('Unknown command');
    }
  }

  private startFlow(): void {
    console.log("Hey you clicked Command 1!")
    const flowURL = "https://yourflowurl"
    fetch(flowURL,{
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({})
      });
    Dialog.alert("Power Automate should of triggered.")
  }
}
